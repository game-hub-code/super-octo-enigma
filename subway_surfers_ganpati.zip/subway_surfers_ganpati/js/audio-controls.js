/*
 * audio-controls.js
 * Adds two on-screen toggles: "Music" (theme.ogg) and "Sound FX" (every other sound).
 * Works by patching the global Howler library the game already uses (window.Howl).
 * Choices are saved in localStorage under ssAudio.music / ssAudio.sfx (default: ON).
 * Load this BEFORE js/boot.js. It does not modify the game's own files.
 */
(function () {
    'use strict';

    var KEY_MUSIC = 'ssAudio.music';
    var KEY_SFX = 'ssAudio.sfx';

    function load(key) {
        try { return window.localStorage.getItem(key) !== '0'; } catch (e) { return true; }
    }
    function save(key, on) {
        try { window.localStorage.setItem(key, on ? '1' : '0'); } catch (e) { /* ignore */ }
    }

    var state = { music: load(KEY_MUSIC), sfx: load(KEY_SFX) };

    /** A Howl is "music" if its source path contains theme.(ogg|mp3|wav). */
    function isMusic(howl) {
        return /(^|\/)theme\.(ogg|mp3|wav)/.test(String(howl && howl._src));
    }
    function isEnabled(howl) {
        return isMusic(howl) ? state.music : state.sfx;
    }

    var buttons = {};

    function refreshButtons() {
        [['music', 'Music'], ['sfx', 'Sound FX']].forEach(function (p) {
            var b = buttons[p[0]];
            if (!b) return;
            var on = state[p[0]];
            b.textContent = p[1] + ': ' + (on ? 'ON' : 'OFF');
            b.setAttribute('aria-pressed', on ? 'true' : 'false');
            b.style.opacity = on ? '1' : '0.6';
            b.style.background = on ? '#2e9e44' : '#8a2b2b';
        });
    }

    /** Apply current state to every Howl that already exists. */
    function applyAll() {
        var list = (window.Howler && window.Howler._howls) || [];
        for (var i = 0; i < list.length; i++) {
            list[i].mute(!isEnabled(list[i]));
        }
    }

    function toggle(which) {
        state[which] = !state[which];
        save(which === 'music' ? KEY_MUSIC : KEY_SFX, state[which]);
        applyAll();
        refreshButtons();
    }

    /* ---------- patch Howler once it has been loaded by boot.js ---------- */
    var patched = false;
    function patch() {
        if (patched || !window.Howl || !window.Howler) return;
        patched = true;
        var proto = window.Howl.prototype;
        var origMute = proto.mute;
        var origPlay = proto.play;

        // If the game tries to un-mute something the player switched off, keep it muted.
        proto.mute = function (muted) {
            if (muted === false && !isEnabled(this)) muted = true;
            return origMute.apply(this, arguments.length ? [muted].concat([].slice.call(arguments, 1)) : arguments);
        };
        // Make sure each sound obeys the switches at the moment it plays.
        proto.play = function () {
            if (!isEnabled(this)) origMute.call(this, true);
            return origPlay.apply(this, arguments);
        };
        applyAll();
    }
    var poll = setInterval(function () {
        patch();
        if (patched) {
            clearInterval(poll);
            // Sounds are created a little later; re-apply for a few seconds.
            var n = 0;
            var again = setInterval(function () { applyAll(); if (++n > 20) clearInterval(again); }, 500);
        }
    }, 50);

    /* ---------- on-screen buttons ---------- */
    function makeButton(which) {
        var b = document.createElement('button');
        b.type = 'button';
        b.tabIndex = -1; // keep keyboard focus on the game (Space/arrows)
        b.style.cssText = 'display:block;margin:0 0 6px 0;padding:6px 10px;border:2px solid #fff;' +
            'border-radius:8px;color:#fff;font:bold 12px Verdana,sans-serif;cursor:pointer;' +
            'min-width:104px;text-align:center;touch-action:manipulation;';
        // Stop the game from treating a button press as a swipe/tap on the canvas.
        ['pointerdown', 'mousedown', 'touchstart', 'touchend', 'keydown', 'keyup'].forEach(function (ev) {
            b.addEventListener(ev, function (e) { e.stopPropagation(); }, false);
        });
        b.addEventListener('mousedown', function (e) { e.preventDefault(); }, false); // no focus steal
        b.addEventListener('click', function (e) {
            e.stopPropagation();
            toggle(which);
            b.blur();
        }, false);
        buttons[which] = b;
        return b;
    }

    function buildUI() {
        var box = document.createElement('div');
        box.id = 'audio-controls';
        // Position: bottom-left corner (the game's own buttons use the top corners and bottom centre).
        // To move it, change bottom/left below (e.g. top:8px;right:8px for top-right).
        box.style.cssText = 'position:fixed;bottom:8px;left:8px;z-index:100000;' +
            'padding-bottom:env(safe-area-inset-bottom,0);padding-left:env(safe-area-inset-left,0);';
        box.appendChild(makeButton('music'));
        box.appendChild(makeButton('sfx'));
        document.body.appendChild(box);
        refreshButtons();
    }

    if (document.body) buildUI();
    else document.addEventListener('DOMContentLoaded', buildUI);

    // Small public handle for testing/debugging in the console: ssAudio.state
    window.ssAudio = { state: state, toggle: toggle };
})();
