const fs = require('fs'), path = require('path');
(async () => {
  const [har, assets] = process.argv.slice(2);
  if (!har || !assets) { console.log('usage: node har-extract.js file.har "assets"'); process.exit(1); }
  const entries = JSON.parse(fs.readFileSync(har, 'utf8')).log.entries;
  const done = new Set(), tried = new Set(); let ok = 0, fail = 0;
  const save = (rel, buf) => {
    const out = path.join(assets, rel);
    fs.mkdirSync(path.dirname(out), { recursive: true });
    fs.writeFileSync(out, buf);
    done.add(rel); ok++;
    console.log('OK   ' + rel + ' (' + buf.length + ' bytes)');
  };
  const list = [];
  for (const e of entries) {
    const u = new URL(e.request.url);
const m = u.pathname.match(/\/assets\/((?:characters-[a-z]+|images)\/[^/]+)$/);
    if (!m) continue;
    list.push({ rel: decodeURIComponent(m[1]), url: e.request.url, u, c: e.response.content || {}, s: e.response.status });
  }
  for (const x of list) {
    if (done.has(x.rel) || x.s !== 200 || !x.c.text) continue;
    save(x.rel, Buffer.from(x.c.text, x.c.encoding === 'base64' ? 'base64' : 'utf8'));
  }
  for (const x of list) {
    if (done.has(x.rel) || tried.has(x.rel) || x.s !== 200) continue;
    tried.add(x.rel);
    try {
      const r = await fetch(x.url, { headers: { Referer: x.u.origin + '/', Origin: x.u.origin } });
      if (!r.ok) throw new Error('HTTP ' + r.status);
      save(x.rel, Buffer.from(await r.arrayBuffer()));
    } catch (err) { fail++; console.log('FAIL ' + x.rel + ' -> ' + err.message + '\n     ' + x.url); }
  }
  console.log(`\nsaved ${ok}, failed ${fail}`);
})();