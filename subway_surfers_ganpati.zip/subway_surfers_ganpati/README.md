# Subway Surfers – Ganpati Edition: File-by-File Guide

Every file in the project is explained on its own row: what it is, how big it is, and how sure that explanation is. 258 files in total: 168 real files + 90 hashed duplicates (each listed right under its original).

> **Tags.** **[VERIFIED]** = checked directly (opened, measured, hashed, or listened to with ffmpeg). **[INFERRED]** = worked out from the file name, folder or size. **[UNKNOWN]** = cannot be told from the files. Nobody ran the game in a browser while writing this. The main game code (`js/index.js`) is minified, so gameplay claims come from names and data, not from reading logic.

## Five findings worth knowing first

1. **The music is silent.** `theme.ogg` is 138 seconds long but its loudest sample is −91 dB (digital silence). The game has no audible background music as shipped. All 28 sound effects are audible.
2. **The loading splash has no Ganpati branding.** `splash.png` is the normal orange "Subway Surfers" logo. Ganesh/Ganpati text exists only in the page title and the webmanifest.
3. **`.gb` files are 3D models with a JSON-like header.** The first bytes are a small binary prefix, then UTF-16 text `{"geometry":[{"name"...`. Not editable with normal tools.
4. **Hashed `_h=sktwi21f0lbkmtyza` files are exact copies.** All 90 were compared with their originals by MD5: identical.
5. **Many textures are tiny.** All 16 hoverboard textures are only 16×16 or 32×32 px. The three Yutani character textures are identical to each other.

## Load order (which file starts what)

`index.html` → `js/loading.js` → `js/boot.js` → `js/dependencies.bundle.js` → `js/index.js` → reads `bundles/1112-winter-holidays/manifest.json` and the files in `assets/`.


---

## Root files

| File | Size | What this file is |
|---|---|---|
| `har-extract.js` | 1.6 KB | Dev-only Node script (needs Node 18+). Usage: `node har-extract.js file.har assets`. Reads a browser HAR recording, finds requests to `assets/characters-*/` and `assets/images/`, saves them (from the HAR body, or re-downloads them with Referer/Origin headers). Not loaded by the game. [VERIFIED code] |
| `index.html` | 31.5 KB | The only page you open. Sets title "Subway Surfers - Ganesh Chaturthi Special", links manifest + icons, shows the splash image and a loading message, has 142 `<link rel="preload">` lines, then an inline config (`NOSW=true`, `leaderboard:'mockup'`, `bundlesPath:'./bundles'`, `window.open` disabled) and loads `loading.js` and `boot.js`. Also holds leftover "Save page as" script paths (yandex-metrica, igroutka) that point outside the project. [VERIFIED] |
| `poki-sdk-core.js` | 233.2 KB | The main Poki SDK code (ads, gameplay/loading events). Third-party, not part of the game itself. Game still starts if it fails (see `boot.js`). [INFERRED from name and boot.js use] |
| `poki-sdk.js` | 5.5 KB | Small loader for the Poki game-portal SDK (webpack-style bootstrap). Loaded by `index.html`. Provides `window.PokiSDK` used by `boot.js`. [VERIFIED head of file; internals INFERRED] |
| `prebid4.12.0.js` | 0 B | Slot for the Prebid.js ad-bidding library, v4.12.0 by name. The file is EMPTY (0 bytes), so it does nothing. [VERIFIED] |
| `subwaysurfers.webmanifest` | 1.5 KB | PWA manifest: name "Subway Surfers - Ganesh Chaturthi", short name "Subway Surfers", `standalone`, background `#0b316b`. Lists 11 icon sizes, but only 5 icon files exist (16/57/72/114/144 px); 48, 96, 168, 192, 256, 512, 1024 are missing. [VERIFIED] |

---

## `js/` – scripts

| File | Size | What this file is |
|---|---|---|
| `boot.js` | 2.6 KB | Startup script. In order: block arrow/Space page-scroll → try `./sw.js` service worker (skipped, `NOSW` is true) → init Poki SDK (continues if it fails or is ad-blocked) → load `js/dependencies.bundle.js`, then `js/index.js` (or `window.MAIN`). [VERIFIED] |
| `dependencies.bundle.js` | 1.51 MB | Webpack bundle of third-party libraries. Names PIXI (2D renderer), Howler (audio), GSAP and tween (animation) appear in the text. Anything else inside is [UNKNOWN]. Loaded by `boot.js` before the game. |
| `index.js` | 922.0 KB | The game itself: menus, runs, scoring, missions, awards, store. Minified with a string-array obfuscation style, so it is not human-readable. Text search shows it uses `localStorage` (6 hits), keyboard events (`keydown`, `ArrowLeft`), the `mockup` leaderboard, and shader-like strings. Detailed logic is [UNKNOWN]. |
| `loading.js` | 2.8 KB | Creates `window.loadingBar`: a 300×30 px black box with an orange (`#f65000`) bar, centered slightly below the middle, label shows `%` and `x/y MB` if a total is set. Methods: `show`, `hide`, `setTotal`, `setProgress`. [VERIFIED] |

---

## `js/workers/`

| File | Size | What this file is |
|---|---|---|
| `worker.0a8b30d0071f04d38b17.js` | 107.3 KB | Webpack-built Web Worker (hashed filename). Starts with the standard webpack module loader. What it computes is [UNKNOWN]. |

---

## `bundles/1112-winter-holidays/` – the theme pack

| File | Size | What this file is |
|---|---|---|
| `manifest.json` | 3.8 KB | Index of the theme bundle. Groups: `default` (empty), `audio-basic`, `game-basic`, `game-full`, `game-idle`. Maps logical names to files, e.g. `environment-basic.fbx` → `environment-basic.gb`. Lists `theme.wav`, `theme.mp3` and `theme.ogg`, but only the OGG exists. [VERIFIED] |

---

## `…/audio-basic/` – music

| File | Size | What this file is |
|---|---|---|
| `theme.ogg` | 18.5 KB | The music track: 138 s, mono, Vorbis, 18.9 KB (≈1 kb/s). **Measured volume: max −91 dB, mean −91 dB = digital silence.** So the game has no audible background music as shipped. To add music, replace this file. [VERIFIED by ffmpeg volumedetect] |

---

## `…/game-basic/` – low-detail world + trains

| File | Size | What this file is |
|---|---|---|
| `environment-basic.gb` | 255.9 KB | Low-detail 3D world/scenery model set loaded to start a run. Format: `.gb`. [INFERRED from name + group] |
| `trains-basic.gb` | 26.9 KB | Low-detail train models for the first stage of loading. [INFERRED] |

---

## `…/game-full/` – full-detail world + trains

| File | Size | What this file is |
|---|---|---|
| `environment-full.gb` | 1.91 MB | Full-detail world/scenery models (the biggest bundle file, 2 MB), loaded after the basic set. [INFERRED] |
| `trains-full.gb` | 98.1 KB | Full-detail train models. [INFERRED] |

---

## `…/game-idle/` – menu-screen world + trains

| File | Size | What this file is |
|---|---|---|
| `environment-idle.gb` | 37.6 KB | World models used on the home/menu screen (idle scene). [INFERRED] |
| `environment-tex.webp` | 49.4 KB | 256×256 texture for the world models. [VERIFIED size; use INFERRED] |
| `train-start.webp` | 84.9 KB | 512×544 texture, preloaded by `index.html`; name suggests the train shown at the start/menu. [INFERRED] |
| `trains-idle.gb` | 35.4 KB | Train models for the menu scene. [INFERRED] |
| `trains-tex.webp` | 40.8 KB | 256×256 texture for the train models. [VERIFIED size; use INFERRED] |

---

## `assets/preload/` – loading splash

| File | Size | What this file is |
|---|---|---|
| `splash.png` | 30.1 KB | 457×235 loading-splash logo. Used as the page background in `index.html`. I viewed it: it is the standard orange graffiti "Subway Surfers" logo, with NO Ganpati/Ganesh branding. [VERIFIED] |
| `splash.webp` | 18.7 KB | 457×235 WebP version of the splash (19 KB vs 31 KB PNG). Preloaded as the hashed copy. [VERIFIED size/dims] |
| `splash_h=sktwi21f0lbkmtyza.webp` | 18.7 KB | Cache-busting duplicate of `splash.webp`, byte-identical (checked by MD5). `index.html` preloads this hashed name. [VERIFIED] |

---

## `assets/ui/` – menu graphics

| File | Size | What this file is |
|---|---|---|
| `ui.webp` | 1.17 MB | 1751×1748 sprite atlas (1.2 MB): all menu panels/buttons in one image (e.g. `notepad-panel`, `scoreboard`, `prizescreen-bg`, `highscorescreen-bg`). [VERIFIED] |
| `ui.webp.json` | 27.3 KB | Map for `ui.webp`: 138 frames, each with x/y/width/height, e.g. `notepad-panel.png` at (2,2) 654×834. TexturePacker-style format. [VERIFIED] |

---

## `assets/font/` – fonts

| File | Size | What this file is |
|---|---|---|
| `lilita-one.woff2` | 19.6 KB | Lilita One web font. Preloaded by `index.html`; where exactly it is used is [UNKNOWN]. |
| `lilita-one_h=sktwi21f0lbkmtyza.woff2` | 19.6 KB | Cache-busting duplicate of `lilita-one.woff2`, byte-identical (checked by MD5). `index.html` preloads this hashed name. [VERIFIED] |
| `stencilia.woff2` | 21.5 KB | Stencilia (stencil-style) web font, preloaded. Usage [UNKNOWN]. |
| `stencilia_h=sktwi21f0lbkmtyza.woff2` | 21.5 KB | Cache-busting duplicate of `stencilia.woff2`, byte-identical (checked by MD5). `index.html` preloads this hashed name. [VERIFIED] |
| `titan-one.woff2` | 17.9 KB | Titan One (chunky display) web font, preloaded. Usage [UNKNOWN]. |
| `titan-one_h=sktwi21f0lbkmtyza.woff2` | 17.9 KB | Cache-busting duplicate of `titan-one.woff2`, byte-identical (checked by MD5). `index.html` preloads this hashed name. [VERIFIED] |

---

## `assets/data/` – text, awards, track layouts

| File | Size | What this file is |
|---|---|---|
| `awards.json` | 1.8 KB | 12 awards, each with bronze/silver/gold/diamond `goal` and `reward`. Keys: collect-coins-single-run (30/120/810/2012), complete-missions, missions-in-one-run, open-mystery-boxes, own-boards, own-characters, own-outfits, pickup-powerups, score-no-change-lanes, score-no-coins, score-no-jump, super-sneakers-minutes. [VERIFIED] |
| `awards_h=sktwi21f0lbkmtyza.json` | 1.8 KB | Cache-busting duplicate of `awards.json`, byte-identical (checked by MD5). `index.html` preloads this hashed name. [VERIFIED] |
| `chunks-basic.json` | 34.2 KB | Track layout data for the first stage. 3 entries: `route-chunk-basic-b-s-b`, `route-chunk-default-fallback`, `route-chunk-default-tutorial`. Each is a named tree of positions (transforms). [VERIFIED] |
| `chunks-basic_h=sktwi21f0lbkmtyza.json` | 34.2 KB | Cache-busting duplicate of `chunks-basic.json`, byte-identical (checked by MD5). `index.html` preloads this hashed name. [VERIFIED] |
| `chunks-full.json` | 1.23 MB | Track layout data, 1.3 MB, 37 top-level entries such as `route-chunk-default-b-s-b`, `-choice`, `-s-b-s-b`, `-train-tops-1/2`, `-tunnel-notrain`, `-ramp-2`, `-short-1-track`. Pieces of track the game joins together. [VERIFIED names; meaning INFERRED] |
| `chunks-full_h=sktwi21f0lbkmtyza.json` | 1.23 MB | Cache-busting duplicate of `chunks-full.json`, byte-identical (checked by MD5). `index.html` preloads this hashed name. [VERIFIED] |
| `chunks-idle.json` | 1.3 KB | Menu-scene layout: one entry, `intro`, with placeholders like `high_tracks3_high_group_place` and `bag_place`. [VERIFIED] |
| `chunks-idle_h=sktwi21f0lbkmtyza.json` | 1.3 KB | Cache-busting duplicate of `chunks-idle.json`, byte-identical (checked by MD5). `index.html` preloads this hashed name. [VERIFIED] |
| `lang-en.json` | 10.1 KB | English UI text: 260 keys (`play`, `pause`, `gameover`, `save_me`, `missions`, `prizes`, `jackpot-coins` "100,000 Coins!", `prize-screen-open` "Press Space to open"). Edit this to change wording. [VERIFIED] |
| `lang-en_h=sktwi21f0lbkmtyza.json` | 10.1 KB | Cache-busting duplicate of `lang-en.json`, byte-identical (checked by MD5). `index.html` preloads this hashed name. [VERIFIED] |
| `lang-pt-br.json` | 10.6 KB | Brazilian Portuguese UI text: 260 keys, same set as English. [VERIFIED count] |
| `lang-pt-br_h=sktwi21f0lbkmtyza.json` | 10.6 KB | Cache-busting duplicate of `lang-pt-br.json`, byte-identical (checked by MD5). `index.html` preloads this hashed name. [VERIFIED] |

---

## `assets/images/` – icons

| File | Size | What this file is |
|---|---|---|
| `app-icon-114.png` | 7.7 KB | 114×114 app icon. iOS icon (114 px). [VERIFIED] |
| `app-icon-144.png` | 10.4 KB | 144×144 app icon. PWA icon (144 px); listed in the webmanifest, NOT linked from `index.html`. [VERIFIED] |
| `app-icon-16.png` | 988 B | 16×16 app icon. Browser tab favicon (`<link rel=icon>`). [VERIFIED] |
| `app-icon-57.png` | 3.4 KB | 57×57 app icon. iOS home-screen icon (`apple-touch-icon-precomposed`). [VERIFIED] |
| `app-icon-72.png` | 4.4 KB | 72×72 app icon. iOS icon (72 px). [VERIFIED] |
| `icon-00-brody.png` | 5.4 KB | 100×100 portrait icon for Brody (character-select UI). [INFERRED use] |
| `icon-01-tagbot.png` | 5.1 KB | 100×100 portrait icon for Tagbot (character-select UI). [INFERRED use] |
| `icon-02-tasha.png` | 5.7 KB | 100×100 portrait icon for Tasha (character-select UI). [INFERRED use] |
| `icon-03-ninja.png` | 3.4 KB | 100×100 portrait icon for Ninja (character-select UI). [INFERRED use] |
| `icon-04-lucy.png` | 5.9 KB | 100×100 portrait icon for Lucy (character-select UI). [INFERRED use] |
| `icon-05-king.png` | 5.5 KB | 100×100 portrait icon for King (character-select UI). [INFERRED use] |
| `icon-07-yutani.png` | 4.3 KB | 100×100 portrait icon for Yutani (character-select UI). [INFERRED use] |
| `icon-08-spike.png` | 5.2 KB | 100×100 portrait icon for Spike (character-select UI). [INFERRED use] No matching model exists in this project. [VERIFIED] |
| `icon-09-fresh.png` | 4.4 KB | 100×100 portrait icon for Fresh (character-select UI). [INFERRED use] No matching model exists in this project. [VERIFIED] |
| `icon-11-tricky.png` | 6.0 KB | 100×100 portrait icon for Tricky (character-select UI). [INFERRED use] |
| `icon-friend.png` | 359 B | 42×42 small "friend" icon (social UI). [INFERRED] |

---

## `assets/audio-basic/` – core sound effects

| File | Size | What this file is |
|---|---|---|
| `guard-catch.ogg` | 13.7 KB | Sound of the guard catching you. Name-based. [INFERRED] |
| `guard-catch_h=sktwi21f0lbkmtyza.ogg` | 13.7 KB | Cache-busting duplicate of `guard-catch.ogg`, byte-identical (checked by MD5). `index.html` preloads this hashed name. [VERIFIED] |
| `guard-proximity.ogg` | 40.3 KB | Longest guard sound (8.8 s): guard/dog getting close behind you. [INFERRED] |
| `guard-proximity_h=sktwi21f0lbkmtyza.ogg` | 40.3 KB | Cache-busting duplicate of `guard-proximity.ogg`, byte-identical (checked by MD5). `index.html` preloads this hashed name. [VERIFIED] |
| `guard-start.ogg` | 17.1 KB | Guard begins chasing (3.5 s). [INFERRED] |
| `guard-start_h=sktwi21f0lbkmtyza.ogg` | 17.1 KB | Cache-busting duplicate of `guard-start.ogg`, byte-identical (checked by MD5). `index.html` preloads this hashed name. [VERIFIED] |
| `hero-death-hitcam.ogg` | 5.4 KB | Short impact sound for the death camera (0.41 s). [INFERRED] |
| `hero-death-hitcam_h=sktwi21f0lbkmtyza.ogg` | 5.4 KB | Cache-busting duplicate of `hero-death-hitcam.ogg`, byte-identical (checked by MD5). `index.html` preloads this hashed name. [VERIFIED] |
| `hero-death.ogg` | 7.0 KB | Player dies / crashes (0.9 s). [INFERRED] |
| `hero-death_h=sktwi21f0lbkmtyza.ogg` | 7.0 KB | Cache-busting duplicate of `hero-death.ogg`, byte-identical (checked by MD5). `index.html` preloads this hashed name. [VERIFIED] |
| `hero-dodge.ogg` | 4.3 KB | Quick whoosh when dodging or changing lanes (0.21 s). [INFERRED] |
| `hero-dodge_h=sktwi21f0lbkmtyza.ogg` | 4.3 KB | Cache-busting duplicate of `hero-dodge.ogg`, byte-identical (checked by MD5). `index.html` preloads this hashed name. [VERIFIED] |
| `hero-foot-l.ogg` | 3.6 KB | Left footstep (0.02 s click). [INFERRED] |
| `hero-foot-l_h=sktwi21f0lbkmtyza.ogg` | 3.6 KB | Cache-busting duplicate of `hero-foot-l.ogg`, byte-identical (checked by MD5). `index.html` preloads this hashed name. [VERIFIED] |
| `hero-foot-r.ogg` | 3.6 KB | Right footstep (0.02 s click). [INFERRED] |
| `hero-foot-r_h=sktwi21f0lbkmtyza.ogg` | 3.6 KB | Cache-busting duplicate of `hero-foot-r.ogg`, byte-identical (checked by MD5). `index.html` preloads this hashed name. [VERIFIED] |
| `hero-hoverboard-crash.ogg` | 7.3 KB | Hoverboard breaks when you hit something (0.9 s). [INFERRED] |
| `hero-hoverboard-crash_h=sktwi21f0lbkmtyza.ogg` | 7.3 KB | Cache-busting duplicate of `hero-hoverboard-crash.ogg`, byte-identical (checked by MD5). `index.html` preloads this hashed name. [VERIFIED] |
| `hero-jump.ogg` | 5.5 KB | Jump sound (0.6 s). [INFERRED] |
| `hero-jump_h=sktwi21f0lbkmtyza.ogg` | 5.5 KB | Cache-busting duplicate of `hero-jump.ogg`, byte-identical (checked by MD5). `index.html` preloads this hashed name. [VERIFIED] |
| `hero-revive.ogg` | 15.8 KB | Revive / "Save me" sound (3.8 s). [INFERRED] |
| `hero-revive_h=sktwi21f0lbkmtyza.ogg` | 15.8 KB | Cache-busting duplicate of `hero-revive.ogg`, byte-identical (checked by MD5). `index.html` preloads this hashed name. [VERIFIED] |
| `hero-roll.ogg` | 4.8 KB | Roll/slide sound (0.35 s). [INFERRED] |
| `hero-roll_h=sktwi21f0lbkmtyza.ogg` | 4.8 KB | Cache-busting duplicate of `hero-roll.ogg`, byte-identical (checked by MD5). `index.html` preloads this hashed name. [VERIFIED] |
| `hero-stumble.ogg` | 5.1 KB | Stumble when clipping an obstacle (0.46 s). [INFERRED] |
| `hero-stumble_h=sktwi21f0lbkmtyza.ogg` | 5.1 KB | Cache-busting duplicate of `hero-stumble.ogg`, byte-identical (checked by MD5). `index.html` preloads this hashed name. [VERIFIED] |
| `unlock.ogg` | 31.1 KB | Unlock jingle (7.8 s), likely for new character/board. [INFERRED] |
| `unlock_h=sktwi21f0lbkmtyza.ogg` | 31.1 KB | Cache-busting duplicate of `unlock.ogg`, byte-identical (checked by MD5). `index.html` preloads this hashed name. [VERIFIED] |

---

## `assets/audio-full/` – extra sound effects

| File | Size | What this file is |
|---|---|---|
| `hero-sneakers-foot-l.ogg` | 3.8 KB | Left footstep while Super Sneakers power-up is active (0.08 s). [INFERRED] |
| `hero-sneakers-foot-l_h=sktwi21f0lbkmtyza.ogg` | 3.8 KB | Cache-busting duplicate of `hero-sneakers-foot-l.ogg`, byte-identical (checked by MD5). `index.html` preloads this hashed name. [VERIFIED] |
| `hero-sneakers-foot-r.ogg` | 3.8 KB | Right footstep with sneakers (0.08 s). [INFERRED] |
| `hero-sneakers-foot-r_h=sktwi21f0lbkmtyza.ogg` | 3.8 KB | Cache-busting duplicate of `hero-sneakers-foot-r.ogg`, byte-identical (checked by MD5). `index.html` preloads this hashed name. [VERIFIED] |
| `hero-sneakers-jump.ogg` | 4.5 KB | Higher-jump sound with sneakers (0.43 s). [INFERRED] |
| `hero-sneakers-jump_h=sktwi21f0lbkmtyza.ogg` | 4.5 KB | Cache-busting duplicate of `hero-sneakers-jump.ogg`, byte-identical (checked by MD5). `index.html` preloads this hashed name. [VERIFIED] |
| `pickup-coin.ogg` | 4.3 KB | Coin pick-up (0.56 s). [INFERRED] |
| `pickup-coin_h=sktwi21f0lbkmtyza.ogg` | 4.3 KB | Cache-busting duplicate of `pickup-coin.ogg`, byte-identical (checked by MD5). `index.html` preloads this hashed name. [VERIFIED] |
| `pickup-powerdown.ogg` | 5.1 KB | Power-up wears off (0.37 s). [INFERRED] |
| `pickup-powerdown_h=sktwi21f0lbkmtyza.ogg` | 5.1 KB | Cache-busting duplicate of `pickup-powerdown.ogg`, byte-identical (checked by MD5). `index.html` preloads this hashed name. [VERIFIED] |
| `pickup-powerup.ogg` | 8.3 KB | Power-up collected (1.64 s). [INFERRED] |
| `pickup-powerup_h=sktwi21f0lbkmtyza.ogg` | 8.3 KB | Cache-busting duplicate of `pickup-powerup.ogg`, byte-identical (checked by MD5). `index.html` preloads this hashed name. [VERIFIED] |
| `special-jetpack-start.ogg` | 12.1 KB | Jetpack ignition (2.2 s). [INFERRED] |
| `special-jetpack-start_h=sktwi21f0lbkmtyza.ogg` | 12.1 KB | Cache-busting duplicate of `special-jetpack-start.ogg`, byte-identical (checked by MD5). `index.html` preloads this hashed name. [VERIFIED] |
| `special-jetpack.ogg` | 17.4 KB | Jetpack flying loop (3.5 s). [INFERRED] |
| `special-jetpack_h=sktwi21f0lbkmtyza.ogg` | 17.4 KB | Cache-busting duplicate of `special-jetpack.ogg`, byte-identical (checked by MD5). `index.html` preloads this hashed name. [VERIFIED] |
| `special-magnet.ogg` | 5.7 KB | Coin-magnet effect (1.5 s); quietest sound in the set (max −16.5 dB). [INFERRED use; VERIFIED level] |
| `special-magnet_h=sktwi21f0lbkmtyza.ogg` | 5.7 KB | Cache-busting duplicate of `special-magnet.ogg`, byte-identical (checked by MD5). `index.html` preloads this hashed name. [VERIFIED] |

---

## `assets/audio-idle/` – menu sound effects

| File | Size | What this file is |
|---|---|---|
| `gui-coin.ogg` | 5.5 KB | Menu coin sound (0.73 s), e.g. counting coins. [INFERRED] |
| `gui-coin_h=sktwi21f0lbkmtyza.ogg` | 5.5 KB | Cache-busting duplicate of `gui-coin.ogg`, byte-identical (checked by MD5). `index.html` preloads this hashed name. [VERIFIED] |
| `gui-tap.ogg` | 3.8 KB | Tiny UI tap (0.05 s). [INFERRED] |
| `gui-tap_h=sktwi21f0lbkmtyza.ogg` | 3.8 KB | Cache-busting duplicate of `gui-tap.ogg`, byte-identical (checked by MD5). `index.html` preloads this hashed name. [VERIFIED] |
| `mission-notification.ogg` | 13.4 KB | Mission-complete notification (3 s). [INFERRED] |
| `mission-notification_h=sktwi21f0lbkmtyza.ogg` | 13.4 KB | Cache-busting duplicate of `mission-notification.ogg`, byte-identical (checked by MD5). `index.html` preloads this hashed name. [VERIFIED] |
| `open-prize.ogg` | 30.4 KB | Mystery-box / prize opening (8 s). [INFERRED] |
| `open-prize_h=sktwi21f0lbkmtyza.ogg` | 30.4 KB | Cache-busting duplicate of `open-prize.ogg`, byte-identical (checked by MD5). `index.html` preloads this hashed name. [VERIFIED] |
| `ui-button.ogg` | 4.8 KB | Menu button press (0.37 s). [INFERRED] |
| `ui-button_h=sktwi21f0lbkmtyza.ogg` | 4.8 KB | Cache-busting duplicate of `ui-button.ogg`, byte-identical (checked by MD5). `index.html` preloads this hashed name. [VERIFIED] |

---

## `assets/boards/` – hoverboards

| File | Size | What this file is |
|---|---|---|
| `board-bigkahuna-tex.webp` | 174 B | Texture for the Big Kahuna board, only 16×32 px. [VERIFIED size; use INFERRED] |
| `board-bigkahuna-tex_h=sktwi21f0lbkmtyza.webp` | 174 B | Cache-busting duplicate of `board-bigkahuna-tex.webp`, byte-identical (checked by MD5). `index.html` preloads this hashed name. [VERIFIED] |
| `board-bigkahuna.gb` | 6.2 KB | 3D model of the "Big Kahuna" hoverboard. [INFERRED from name] |
| `board-bigkahuna_h=sktwi21f0lbkmtyza.gb` | 6.2 KB | Cache-busting duplicate of `board-bigkahuna.gb`, byte-identical (checked by MD5). `index.html` preloads this hashed name. [VERIFIED] |
| `board-bouncer-tex.webp` | 142 B | Texture for the Bouncer board, only 16×16 px. [VERIFIED size; use INFERRED] |
| `board-bouncer-tex_h=sktwi21f0lbkmtyza.webp` | 142 B | Cache-busting duplicate of `board-bouncer-tex.webp`, byte-identical (checked by MD5). `index.html` preloads this hashed name. [VERIFIED] |
| `board-bouncer.gb` | 6.0 KB | 3D model of the "Bouncer" hoverboard. [INFERRED from name] |
| `board-bouncer_h=sktwi21f0lbkmtyza.gb` | 6.0 KB | Cache-busting duplicate of `board-bouncer.gb`, byte-identical (checked by MD5). `index.html` preloads this hashed name. [VERIFIED] |
| `board-daredevil-tex.webp` | 144 B | Texture for the Daredevil board, only 16×16 px. [VERIFIED size; use INFERRED] |
| `board-daredevil-tex_h=sktwi21f0lbkmtyza.webp` | 144 B | Cache-busting duplicate of `board-daredevil-tex.webp`, byte-identical (checked by MD5). `index.html` preloads this hashed name. [VERIFIED] |
| `board-daredevil.gb` | 12.6 KB | 3D model of the "Daredevil" hoverboard. [INFERRED from name] |
| `board-daredevil_h=sktwi21f0lbkmtyza.gb` | 12.6 KB | Cache-busting duplicate of `board-daredevil.gb`, byte-identical (checked by MD5). `index.html` preloads this hashed name. [VERIFIED] |
| `board-greatwhite-tex.webp` | 156 B | Texture for the Great White board, only 16×16 px. [VERIFIED size; use INFERRED] |
| `board-greatwhite-tex_h=sktwi21f0lbkmtyza.webp` | 156 B | Cache-busting duplicate of `board-greatwhite-tex.webp`, byte-identical (checked by MD5). `index.html` preloads this hashed name. [VERIFIED] |
| `board-greatwhite.gb` | 19.0 KB | 3D model of the "Great White" hoverboard. [INFERRED from name] |
| `board-greatwhite_h=sktwi21f0lbkmtyza.gb` | 19.0 KB | Cache-busting duplicate of `board-greatwhite.gb`, byte-identical (checked by MD5). `index.html` preloads this hashed name. [VERIFIED] |
| `board-hotrod-tex.webp` | 198 B | Texture for the Hot Rod board, only 16×16 px. [VERIFIED size; use INFERRED] |
| `board-hotrod-tex_h=sktwi21f0lbkmtyza.webp` | 198 B | Cache-busting duplicate of `board-hotrod-tex.webp`, byte-identical (checked by MD5). `index.html` preloads this hashed name. [VERIFIED] |
| `board-hotrod.gb` | 18.2 KB | 3D model of the "Hot Rod" hoverboard. [INFERRED from name] |
| `board-hotrod_h=sktwi21f0lbkmtyza.gb` | 18.2 KB | Cache-busting duplicate of `board-hotrod.gb`, byte-identical (checked by MD5). `index.html` preloads this hashed name. [VERIFIED] |
| `board-hoverboard-tex.webp` | 150 B | Texture for the Hoverboard (basic) board, only 16×16 px. [VERIFIED size; use INFERRED] |
| `board-hoverboard-tex_h=sktwi21f0lbkmtyza.webp` | 150 B | Cache-busting duplicate of `board-hoverboard-tex.webp`, byte-identical (checked by MD5). `index.html` preloads this hashed name. [VERIFIED] |
| `board-hoverboard.gb` | 6.2 KB | 3D model of the "Hoverboard (basic)" hoverboard. [INFERRED from name] |
| `board-hoverboard_h=sktwi21f0lbkmtyza.gb` | 6.2 KB | Cache-busting duplicate of `board-hoverboard.gb`, byte-identical (checked by MD5). `index.html` preloads this hashed name. [VERIFIED] |
| `board-lowrider-tex.webp` | 234 B | Texture for the Lowrider board, only 32×32 px. [VERIFIED size; use INFERRED] |
| `board-lowrider-tex_h=sktwi21f0lbkmtyza.webp` | 234 B | Cache-busting duplicate of `board-lowrider-tex.webp`, byte-identical (checked by MD5). `index.html` preloads this hashed name. [VERIFIED] |
| `board-lowrider.gb` | 8.1 KB | 3D model of the "Lowrider" hoverboard. [INFERRED from name] |
| `board-lowrider_h=sktwi21f0lbkmtyza.gb` | 8.1 KB | Cache-busting duplicate of `board-lowrider.gb`, byte-identical (checked by MD5). `index.html` preloads this hashed name. [VERIFIED] |
| `board-lumberjack-tex.webp` | 146 B | Texture for the Lumberjack board, only 16×16 px. [VERIFIED size; use INFERRED] |
| `board-lumberjack-tex_h=sktwi21f0lbkmtyza.webp` | 146 B | Cache-busting duplicate of `board-lumberjack-tex.webp`, byte-identical (checked by MD5). `index.html` preloads this hashed name. [VERIFIED] |
| `board-lumberjack.gb` | 21.0 KB | 3D model of the "Lumberjack" hoverboard. [INFERRED from name] |
| `board-lumberjack_h=sktwi21f0lbkmtyza.gb` | 21.0 KB | Cache-busting duplicate of `board-lumberjack.gb`, byte-identical (checked by MD5). `index.html` preloads this hashed name. [VERIFIED] |
| `board-monster-tex.webp` | 150 B | Texture for the Monster board, only 16×16 px. [VERIFIED size; use INFERRED] |
| `board-monster-tex_h=sktwi21f0lbkmtyza.webp` | 150 B | Cache-busting duplicate of `board-monster-tex.webp`, byte-identical (checked by MD5). `index.html` preloads this hashed name. [VERIFIED] |
| `board-monster.gb` | 18.0 KB | 3D model of the "Monster" hoverboard. [INFERRED from name] |
| `board-monster_h=sktwi21f0lbkmtyza.gb` | 18.0 KB | Cache-busting duplicate of `board-monster.gb`, byte-identical (checked by MD5). `index.html` preloads this hashed name. [VERIFIED] |
| `board-scoot-tex.webp` | 132 B | Texture for the Scoot board, only 16×16 px. [VERIFIED size; use INFERRED] |
| `board-scoot-tex_h=sktwi21f0lbkmtyza.webp` | 132 B | Cache-busting duplicate of `board-scoot-tex.webp`, byte-identical (checked by MD5). `index.html` preloads this hashed name. [VERIFIED] |
| `board-scoot.gb` | 7.8 KB | 3D model of the "Scoot" hoverboard. [INFERRED from name] |
| `board-scoot_h=sktwi21f0lbkmtyza.gb` | 7.8 KB | Cache-busting duplicate of `board-scoot.gb`, byte-identical (checked by MD5). `index.html` preloads this hashed name. [VERIFIED] |
| `board-skullfire-tex.webp` | 142 B | Texture for the Skullfire board, only 16×16 px. [VERIFIED size; use INFERRED] |
| `board-skullfire-tex_h=sktwi21f0lbkmtyza.webp` | 142 B | Cache-busting duplicate of `board-skullfire-tex.webp`, byte-identical (checked by MD5). `index.html` preloads this hashed name. [VERIFIED] |
| `board-skullfire.gb` | 24.8 KB | 3D model of the "Skullfire" hoverboard. [INFERRED from name] |
| `board-skullfire_h=sktwi21f0lbkmtyza.gb` | 24.8 KB | Cache-busting duplicate of `board-skullfire.gb`, byte-identical (checked by MD5). `index.html` preloads this hashed name. [VERIFIED] |
| `board-starboard-tex.webp` | 282 B | Texture for the Starboard board, only 32×32 px. [VERIFIED size; use INFERRED] |
| `board-starboard-tex_h=sktwi21f0lbkmtyza.webp` | 282 B | Cache-busting duplicate of `board-starboard-tex.webp`, byte-identical (checked by MD5). `index.html` preloads this hashed name. [VERIFIED] |
| `board-starboard.gb` | 14.6 KB | 3D model of the "Starboard" hoverboard. [INFERRED from name] |
| `board-starboard_h=sktwi21f0lbkmtyza.gb` | 14.6 KB | Cache-busting duplicate of `board-starboard.gb`, byte-identical (checked by MD5). `index.html` preloads this hashed name. [VERIFIED] |
| `board-sunset-tex.webp` | 156 B | Texture for the Sunset board, only 16×16 px. [VERIFIED size; use INFERRED] |
| `board-sunset-tex_h=sktwi21f0lbkmtyza.webp` | 156 B | Cache-busting duplicate of `board-sunset-tex.webp`, byte-identical (checked by MD5). `index.html` preloads this hashed name. [VERIFIED] |
| `board-sunset.gb` | 26.6 KB | 3D model of the "Sunset" hoverboard. [INFERRED from name] |
| `board-sunset_h=sktwi21f0lbkmtyza.gb` | 26.6 KB | Cache-busting duplicate of `board-sunset.gb`, byte-identical (checked by MD5). `index.html` preloads this hashed name. [VERIFIED] |
| `board-superhero-tex.webp` | 160 B | Texture for the Superhero board, only 16×16 px. [VERIFIED size; use INFERRED] |
| `board-superhero-tex_h=sktwi21f0lbkmtyza.webp` | 160 B | Cache-busting duplicate of `board-superhero-tex.webp`, byte-identical (checked by MD5). `index.html` preloads this hashed name. [VERIFIED] |
| `board-superhero.gb` | 15.4 KB | 3D model of the "Superhero" hoverboard. [INFERRED from name] |
| `board-superhero_h=sktwi21f0lbkmtyza.gb` | 15.4 KB | Cache-busting duplicate of `board-superhero.gb`, byte-identical (checked by MD5). `index.html` preloads this hashed name. [VERIFIED] |
| `board-teleporter-tex.webp` | 88 B | Texture for the Teleporter board, only 16×16 px. [VERIFIED size; use INFERRED] |
| `board-teleporter-tex_h=sktwi21f0lbkmtyza.webp` | 88 B | Cache-busting duplicate of `board-teleporter-tex.webp`, byte-identical (checked by MD5). `index.html` preloads this hashed name. [VERIFIED] |
| `board-teleporter.gb` | 5.0 KB | 3D model of the "Teleporter" hoverboard. [INFERRED from name] |
| `board-teleporter_h=sktwi21f0lbkmtyza.gb` | 5.0 KB | Cache-busting duplicate of `board-teleporter.gb`, byte-identical (checked by MD5). `index.html` preloads this hashed name. [VERIFIED] |
| `board-windglider-tex.webp` | 118 B | Texture for the Windglider board, only 16×16 px. [VERIFIED size; use INFERRED] |
| `board-windglider-tex_h=sktwi21f0lbkmtyza.webp` | 118 B | Cache-busting duplicate of `board-windglider-tex.webp`, byte-identical (checked by MD5). `index.html` preloads this hashed name. [VERIFIED] |
| `board-windglider.gb` | 9.5 KB | 3D model of the "Windglider" hoverboard. [INFERRED from name] |
| `board-windglider_h=sktwi21f0lbkmtyza.gb` | 9.5 KB | Cache-busting duplicate of `board-windglider.gb`, byte-identical (checked by MD5). `index.html` preloads this hashed name. [VERIFIED] |

---

## `assets/characters-basic/` – in-run character

| File | Size | What this file is |
|---|---|---|
| `jake-game.gb` | 2.70 MB | In-run 3D model of Jake (2.8 MB, largest character file). It is the only in-run character model in the project. Starts with a small binary prefix followed by UTF-16 text `{"geometry":[{"name"...`, so the `.gb` header is JSON-like. [VERIFIED first bytes] |

---

## `assets/characters-idle/` – menu characters

| File | Size | What this file is |
|---|---|---|
| `brody-idle.gb` | 305.4 KB | Menu/home-screen 3D model of Brody. [INFERRED from folder + name] |
| `brody-tex-1.webp` | 6.3 KB | 256×256 texture variant 1 for Brody (likely outfit/colour variants). [INFERRED use] |
| `brody-tex-2.webp` | 6.4 KB | 256×256 texture variant 2 for Brody (likely outfit/colour variants). [INFERRED use] |
| `brody-tex.webp` | 6.6 KB | 256×256 base texture for Brody (likely outfit/colour variants). [INFERRED use] |
| `jake-idle.gb` | 257.0 KB | Menu/home-screen 3D model of Jake. [INFERRED from folder + name] |
| `jake-tex-1.webp` | 64.6 KB | 256×256 texture variant 1 for Jake (likely outfit/colour variants). [INFERRED use] |
| `jake-tex-2.webp` | 75.5 KB | 256×256 texture variant 2 for Jake (likely outfit/colour variants). [INFERRED use] |
| `jake-tex.webp` | 75.5 KB | 256×256 base texture for Jake (likely outfit/colour variants). [INFERRED use] |
| `king-idle.gb` | 214.7 KB | Menu/home-screen 3D model of King. [INFERRED from folder + name] |
| `king-tex-1.webp` | 6.5 KB | 256×256 texture variant 1 for King (likely outfit/colour variants). [INFERRED use] |
| `king-tex-2.webp` | 6.5 KB | 256×256 texture variant 2 for King (likely outfit/colour variants). [INFERRED use] |
| `king-tex.webp` | 6.3 KB | 256×256 base texture for King (likely outfit/colour variants). [INFERRED use] |
| `lucy-idle.gb` | 234.0 KB | Menu/home-screen 3D model of Lucy. [INFERRED from folder + name] |
| `lucy-tex-1.webp` | 5.9 KB | 256×256 texture variant 1 for Lucy (likely outfit/colour variants). [INFERRED use] |
| `lucy-tex-2.webp` | 6.6 KB | 256×256 texture variant 2 for Lucy (likely outfit/colour variants). [INFERRED use] |
| `lucy-tex.webp` | 5.9 KB | 256×256 base texture for Lucy (likely outfit/colour variants). [INFERRED use] |
| `ninja-idle.gb` | 241.5 KB | Menu/home-screen 3D model of Ninja. [INFERRED from folder + name] |
| `ninja-tex-1.webp` | 4.6 KB | 256×256 texture variant 1 for Ninja (likely outfit/colour variants). [INFERRED use] |
| `ninja-tex-2.webp` | 5.7 KB | 256×256 texture variant 2 for Ninja (likely outfit/colour variants). [INFERRED use] |
| `ninja-tex.webp` | 3.7 KB | 256×256 base texture for Ninja (likely outfit/colour variants). [INFERRED use] |
| `tagbot-idle.gb` | 229.2 KB | Menu/home-screen 3D model of Tagbot. [INFERRED from folder + name] |
| `tagbot-tex-1.webp` | 7.3 KB | 256×256 texture variant 1 for Tagbot (likely outfit/colour variants). [INFERRED use] |
| `tagbot-tex-2.webp` | 7.0 KB | 256×256 texture variant 2 for Tagbot (likely outfit/colour variants). [INFERRED use] |
| `tagbot-tex.webp` | 6.6 KB | 256×256 base texture for Tagbot (likely outfit/colour variants). [INFERRED use] |
| `tasha-idle.gb` | 252.7 KB | Menu/home-screen 3D model of Tasha. [INFERRED from folder + name] |
| `tasha-tex-1.webp` | 7.9 KB | 256×256 texture variant 1 for Tasha (likely outfit/colour variants). [INFERRED use] |
| `tasha-tex-2.webp` | 7.2 KB | 256×256 texture variant 2 for Tasha (likely outfit/colour variants). [INFERRED use] |
| `tasha-tex.webp` | 7.3 KB | 256×256 base texture for Tasha (likely outfit/colour variants). [INFERRED use] |
| `tricky-idle.gb` | 329.2 KB | Menu/home-screen 3D model of Tricky. [INFERRED from folder + name] |
| `tricky-tex-1.webp` | 6.7 KB | 256×256 texture variant 1 for Tricky (likely outfit/colour variants). [INFERRED use] |
| `tricky-tex-2.webp` | 7.7 KB | 256×256 texture variant 2 for Tricky (likely outfit/colour variants). [INFERRED use] |
| `tricky-tex.webp` | 7.0 KB | 256×256 base texture for Tricky (likely outfit/colour variants). [INFERRED use] |
| `yutani-idle.gb` | 221.5 KB | Menu/home-screen 3D model of Yutani. [INFERRED from folder + name] |
| `yutani-tex-1.webp` | 5.4 KB | 256×256 texture variant 1 for Yutani (likely outfit/colour variants). [INFERRED use] All three Yutani textures are byte-identical (same MD5), so there are no real variants for this character. [VERIFIED] |
| `yutani-tex-2.webp` | 5.4 KB | 256×256 texture variant 2 for Yutani (likely outfit/colour variants). [INFERRED use] All three Yutani textures are byte-identical (same MD5), so there are no real variants for this character. [VERIFIED] |
| `yutani-tex.webp` | 5.4 KB | 256×256 base texture for Yutani (likely outfit/colour variants). [INFERRED use] All three Yutani textures are byte-identical (same MD5), so there are no real variants for this character. [VERIFIED] |

---

## `assets/game-basic/` – in-run essentials

| File | Size | What this file is |
|---|---|---|
| `atlanta-scroll.webp` | 1.1 KB | 256×256 scrolling background texture; name suggests an Atlanta city backdrop. [INFERRED] |
| `atlanta-scroll_h=sktwi21f0lbkmtyza.webp` | 1.1 KB | Cache-busting duplicate of `atlanta-scroll.webp`, byte-identical (checked by MD5). `index.html` preloads this hashed name. [VERIFIED] |
| `effects-tex.webp` | 506 B | 64×32 effects sprite sheet (tiny). [INFERRED] |
| `effects-tex_h=sktwi21f0lbkmtyza.webp` | 506 B | Cache-busting duplicate of `effects-tex.webp`, byte-identical (checked by MD5). `index.html` preloads this hashed name. [VERIFIED] |
| `enemies.webp` | 6.3 KB | 256×256 texture, most detailed of this set; presumably guard/dog textures. [INFERRED] |
| `enemies_h=sktwi21f0lbkmtyza.webp` | 6.3 KB | Cache-busting duplicate of `enemies.webp`, byte-identical (checked by MD5). `index.html` preloads this hashed name. [VERIFIED] |
| `halo.webp` | 632 B | 132×132 glow sprite. [INFERRED] |
| `halo_h=sktwi21f0lbkmtyza.webp` | 632 B | Cache-busting duplicate of `halo.webp`, byte-identical (checked by MD5). `index.html` preloads this hashed name. [VERIFIED] |
| `havana-waterfall.webp` | 278 B | 32×64 waterfall texture for a Havana scene. [INFERRED] |
| `havana-waterfall_h=sktwi21f0lbkmtyza.webp` | 278 B | Cache-busting duplicate of `havana-waterfall.webp`, byte-identical (checked by MD5). `index.html` preloads this hashed name. [VERIFIED] |
| `jetpack-smoke.webp` | 7.4 KB | 256×64 smoke sprite strip for the jetpack. [INFERRED] |
| `jetpack-smoke_h=sktwi21f0lbkmtyza.webp` | 7.4 KB | Cache-busting duplicate of `jetpack-smoke.webp`, byte-identical (checked by MD5). `index.html` preloads this hashed name. [VERIFIED] |
| `model-dog-catch.gb` | 123.0 KB | 3D dog model with the catching animation (126 KB). [INFERRED] |
| `model-dog-catch_h=sktwi21f0lbkmtyza.gb` | 123.0 KB | Cache-busting duplicate of `model-dog-catch.gb`, byte-identical (checked by MD5). `index.html` preloads this hashed name. [VERIFIED] |
| `model-dog-movement.gb` | 80.4 KB | 3D dog model with running animation (82 KB). [INFERRED] |
| `model-dog-movement_h=sktwi21f0lbkmtyza.gb` | 80.4 KB | Cache-busting duplicate of `model-dog-movement.gb`, byte-identical (checked by MD5). `index.html` preloads this hashed name. [VERIFIED] |
| `model-guard-catch.gb` | 160.1 KB | 3D guard model with catching animation (164 KB). [INFERRED] |
| `model-guard-catch_h=sktwi21f0lbkmtyza.gb` | 160.1 KB | Cache-busting duplicate of `model-guard-catch.gb`, byte-identical (checked by MD5). `index.html` preloads this hashed name. [VERIFIED] |
| `model-guard-movement.gb` | 152.8 KB | 3D guard model with running animation (156 KB). [INFERRED] |
| `model-guard-movement_h=sktwi21f0lbkmtyza.gb` | 152.8 KB | Cache-busting duplicate of `model-guard-movement.gb`, byte-identical (checked by MD5). `index.html` preloads this hashed name. [VERIFIED] |
| `ocean.webp` | 1.9 KB | 256×256 ocean/water texture. [INFERRED] |
| `ocean_h=sktwi21f0lbkmtyza.webp` | 1.9 KB | Cache-busting duplicate of `ocean.webp`, byte-identical (checked by MD5). `index.html` preloads this hashed name. [VERIFIED] |
| `shadow.webp` | 3.0 KB | 132×132 soft shadow sprite drawn under characters. [INFERRED] |
| `shadow_h=sktwi21f0lbkmtyza.webp` | 3.0 KB | Cache-busting duplicate of `shadow.webp`, byte-identical (checked by MD5). `index.html` preloads this hashed name. [VERIFIED] |
| `snow.webp` | 254 B | 16×16 snow particle texture. [INFERRED] |
| `snow_h=sktwi21f0lbkmtyza.webp` | 254 B | Cache-busting duplicate of `snow.webp`, byte-identical (checked by MD5). `index.html` preloads this hashed name. [VERIFIED] |
| `spray-splash.webp` | 684 B | 32×32 splash particle texture. [INFERRED] |
| `spray-splash_h=sktwi21f0lbkmtyza.webp` | 684 B | Cache-busting duplicate of `spray-splash.webp`, byte-identical (checked by MD5). `index.html` preloads this hashed name. [VERIFIED] |
| `waterfall.webp` | 250 B | 32×64 waterfall texture. [INFERRED] |
| `waterfall_h=sktwi21f0lbkmtyza.webp` | 250 B | Cache-busting duplicate of `waterfall.webp`, byte-identical (checked by MD5). `index.html` preloads this hashed name. [VERIFIED] |

---

## `assets/game-full/` – track props

| File | Size | What this file is |
|---|---|---|
| `props-extra.gb` | 73.6 KB | Additional props (75 KB). [INFERRED] |
| `props-extra_h=sktwi21f0lbkmtyza.gb` | 73.6 KB | Cache-busting duplicate of `props-extra.gb`, byte-identical (checked by MD5). `index.html` preloads this hashed name. [VERIFIED] |
| `props.gb` | 606.4 KB | Main track props/obstacles model set (621 KB). Loaded in the full stage. [INFERRED] |
| `props_h=sktwi21f0lbkmtyza.gb` | 606.4 KB | Cache-busting duplicate of `props.gb`, byte-identical (checked by MD5). `index.html` preloads this hashed name. [VERIFIED] |

---

## `assets/game-idle/` – menu-scene props

| File | Size | What this file is |
|---|---|---|
| `mystery-box.gb` | 6.3 KB | 3D mystery-box model for the menu/prize screen. [INFERRED] |
| `mystery-box_h=sktwi21f0lbkmtyza.gb` | 6.3 KB | Cache-busting duplicate of `mystery-box.gb`, byte-identical (checked by MD5). `index.html` preloads this hashed name. [VERIFIED] |
| `props-start.gb` | 37.3 KB | Props for the start/menu scene (38 KB). [INFERRED] |
| `props-start_h=sktwi21f0lbkmtyza.gb` | 37.3 KB | Cache-busting duplicate of `props-start.gb`, byte-identical (checked by MD5). `index.html` preloads this hashed name. [VERIFIED] |
| `props-tex.webp` | 76.5 KB | 256×256 props texture (78 KB), preloaded by `index.html`. [VERIFIED size] |
| `props-tex_h=sktwi21f0lbkmtyza.webp` | 76.5 KB | Cache-busting duplicate of `props-tex.webp`, byte-identical (checked by MD5). `index.html` preloads this hashed name. [VERIFIED] |

---

## Files that the project references but does not contain

| Referenced file | Where it is referenced | Effect |
|---|---|---|
| `sw.js` | `js/boot.js` | Skipped, because `NOSW = true`. No offline mode. |
| `assets/images/app-icon-48/96/168/192/256/512/1024.png` | `subwaysurfers.webmanifest` | Missing icons for PWA install. |
| `bundles/…/audio-basic/theme.wav` and `theme.mp3` | `manifest.json` | Only the OGG exists. |
| `.fbx` originals (e.g. `environment-basic.fbx`) | `manifest.json` | Only converted `.gb` files ship. |
| `../../../../../../cdn.jsdelivr.net/.../tag.js` and `.../m.igroutka.ru/.../scr.js` | `index.html` | Point outside the project; leftover from a saved web page. |
| `assets/images/icon-06-*` and `icon-10-*` | numbering gap | Two character icons in the numbering are absent (their purpose is [UNKNOWN]). |

## Quick "which file do I edit?" table

| Goal | File |
|---|---|
| Change page title | `index.html` (`<title>`) |
| Change app name / theme colour | `subwaysurfers.webmanifest` |
| Change loading logo | `assets/preload/splash.png` (+ `splash.webp` and its hashed copy) |
| Add music | `bundles/1112-winter-holidays/audio-basic/theme.ogg` (currently silent) |
| Change a sound effect | The `.ogg` in `assets/audio-*/` **and** its `_h=` copy |
| Change UI wording | `assets/data/lang-en.json` **and** `lang-en_h=sktwi21f0lbkmtyza.json` |
| Change award goals/rewards | `assets/data/awards.json` and its `_h=` copy |
| Re-colour world / trains | `bundles/…/game-idle/environment-tex.webp`, `trains-tex.webp`, `train-start.webp` |
| Fix missing icons | Add the PNGs to `assets/images/` or edit the manifest |
| Rebuild missing character/image files | `har-extract.js` |

Which copy the game actually loads (plain or hashed) is [UNKNOWN]: edit both to be safe.

*Rights note: the game, art and audio belong to their original owners (Kiloo/SYBO; Poki for the SDK). Confirm you may host or share this before publishing.*